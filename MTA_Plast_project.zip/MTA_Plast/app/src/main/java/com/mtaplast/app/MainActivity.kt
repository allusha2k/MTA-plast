package com.mtaplast.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.content.*
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

data class Product(var name:String,var qty:Int,var cost:Double)
data class Sale(val name:String,val qty:Int,val price:Double,val cost:Double,val date:String)

class MainActivity: Activity() {
    val products=mutableListOf<Product>(); val sales=mutableListOf<Sale>()
    lateinit var box: LinearLayout
    val df=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault())
    override fun onCreate(b:Bundle?){super.onCreate(b); home()}
    fun base(title:String):LinearLayout{ box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(28,28,28,28)
        val t=TextView(this); t.text=title; t.textSize=28f; t.setTextColor(Color.BLACK); t.setPadding(0,0,0,25); box.addView(t); setContentView(box); return box}
    fun btn(s:String, f:()->Unit){val b=Button(this); b.text=s; b.textSize=18f; b.setOnClickListener{f()}; box.addView(b)}
    fun home(){base("MTA Plast"); btn("📦 المخزون"){inventory()}; btn("🛒 بيع"){sell()}; btn("💰 الأرباح"){profits()}; btn("📊 التقارير"){report()}}
    fun inventory(){base("المخزون"); btn("➕ إضافة صنف"){addProduct()}; products.forEachIndexed{ i,p-> val t=TextView(this); t.text="${p.name}  |  ${p.qty} قطعة  |  تكلفة: $${"%.2f".format(p.cost)}"; t.textSize=18f; t.setPadding(0,12,0,12); box.addView(t)}; btn("⬅ رجوع"){home()}}
    fun addProduct(){base("إضافة صنف"); val n=EditText(this); n.hint="اسم الصنف"; val q=EditText(this); q.hint="عدد القطع"; q.inputType=2; val c=EditText(this); c.hint="رأس مال القطعة ($)"; c.inputType=8194; box.addView(n);box.addView(q);box.addView(c);btn("حفظ"){if(n.text.isNotBlank()&&q.text.isNotBlank()&&c.text.isNotBlank()){products.add(Product(n.text.toString(),q.text.toString().toInt(),c.text.toString().toDouble()));inventory()}else Toast.makeText(this,"عبّي كل الخانات",Toast.LENGTH_SHORT).show()};btn("⬅ رجوع"){inventory()}}
    fun sell(){base("بيع"); if(products.isEmpty()){val t=TextView(this);t.text="ما في أصناف. أضف بضاعة أولاً.";t.textSize=18f;box.addView(t);btn("⬅ المخزون"){inventory()};return}
        val names=products.map{it.name}; val sp=Spinner(this); sp.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,names); val q=EditText(this);q.hint="الكمية";q.inputType=2;val price=EditText(this);price.hint="سعر البيع للقطعة ($)";price.inputType=8194;box.addView(sp);box.addView(q);box.addView(price)
        btn("تسجيل البيع"){try{val p=products[sp.selectedItemPosition];val qty=q.text.toString().toInt();val pr=price.text.toString().toDouble();if(qty<=0||qty>p.qty)throw Exception();p.qty-=qty;sales.add(Sale(p.name,qty,pr,p.cost,df.format(Date())));Toast.makeText(this,"تم البيع — الربح: $${"%.2f".format((pr-p.cost)*qty)}",Toast.LENGTH_LONG).show();sell()}catch(e:Exception){Toast.makeText(this,"تأكد من الكمية والسعر",Toast.LENGTH_SHORT).show()}};btn("⬅ رجوع"){home()}}
    fun profits(){base("الأرباح");var rev=0.0;var cap=0.0;sales.forEach{rev+=it.price*it.qty;cap+=it.cost*it.qty};val t=TextView(this);t.text="إجمالي المبيعات: $${"%.2f".format(rev)}\nرأس المال المباع: $${"%.2f".format(cap)}\nالربح: $${"%.2f".format(rev-cap)}";t.textSize=21f;box.addView(t);btn("⬅ رجوع"){home()}}
    fun report(){base("التقارير");if(sales.isEmpty()){val t=TextView(this);t.text="لا توجد عمليات بيع بعد.";t.textSize=18f;box.addView(t)}else sales.reversed().forEach{val t=TextView(this);t.text="${it.date} — ${it.name} ×${it.qty} — بيع $${"%.2f".format(it.price*it.qty)} — ربح $${"%.2f".format((it.price-it.cost)*it.qty)}";t.textSize=16f;t.setPadding(0,10,0,10);box.addView(t)};btn("⬅ رجوع"){home()}}
}